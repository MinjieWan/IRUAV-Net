import warnings, os, sys

os.environ["CUDA_VISIBLE_DEVICES"] = '0'
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
from prettytable import PrettyTable
from ultralytics import YOLO
from ultralytics.utils.torch_utils import model_info
from ultralytics.utils import LOGGER

def get_weight_size(path):
    stats = os.stat(path)
    return f'{stats.st_size / 1024 / 1024:.1f}'

if __name__ == '__main__':
    model_path = r'C:\Users\ADMIN\Desktop\IRUAV-Net-Demo\IRUAV-Net(C+D).engine'
    imgsz = 640
    model = YOLO(model_path)
    result = model.val(data=r'C:\Users\ADMIN\Desktop\IRUAV-Net-Demo\val_HIT_UAV\UAV.yaml',
                       split='val',
                       imgsz=imgsz,
                       batch=1,
                       rect=False,
                       project='val',
                       name='exp',
                       device=os.environ.get("CUDA_VISIBLE_DEVICES", 0),
                       )
